
package lab4p1_jafethou;
import java.util.Scanner;
public class Lab4P1_JafetHou {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int resp = 1;
        while (resp != 3){
            System.out.println("1. Conjuntos ");
            System.out.println("2. Contrasena Mejorada ");
            System.out.println("Ingrese su opcion: ");
            int opc = sc.nextInt();
            switch(opc){
                case 1:{
                    String letra1,letra2;
                    System.out.println("Ingrese el conjunto A: ");
                    letra1= sc.next();
                    System.out.println("Ingrese el conjunto B: ");
                    letra2= sc.next();
                    if (letra1.equals(letra2)){
                        System.out.println("Los conjuntos son iguales ");
                        System.out.println("");
                    }
                    else{
                        System.out.println("Los conjuntos son diferentes ");
                        System.out.println("");
                        String acum1;
                        String acum2;
                        String C ="";
                        String inter ="";
                        int cod1, cod2;
                         for (int i = 0; i< letra1.length(); i++){
                            cod1 = letra1.charAt(i);
                            
                            for (int y = 0; y< letra2.length(); y++){
                                cod2 = letra2.charAt(y);
                                    if (cod1 == cod2){
                                        C += letra1.charAt(i)+","+letra2.charAt(y)+",";
                                        
                                    }
                                    else{
                                        inter += letra1.charAt(i)+",";
                                        
                                    }
                                    
                            }
                        }
                        
                    }
                    break;
                    
                }
                case 2:
                    boolean numero = false;
                    boolean contrasena = false;
                    String contra1,num1;
                    String num2 = "0123456789";
                    String contra2 = "aAbBcCdDeEFfGgHhIijJkKlLmMnNoOpPqQRrRsStTUuVvWwXxYyZz";
                    int contarnum = 0;
                    int contarletras = 0;
                    System.out.println("Ingrese la contrasena: ");
                    contra1= sc.next();
                    System.out.println("Ingrese un numero: ");
                    num1= sc.next();
                    for (int i = 0; i < contra1.length(); i++){
                        char vali = contra1.charAt(i);
                        int contador = vali;
                        
                        if (contador >= 48 && contador <= 57){
                            contarnum++;
                            numero = true;
                        }
                        else{

                        }
                        if (contador >= 97 && contador <= 122){
                            contarletras++;
                        }
                        else{

                        }



                    }
                    String contra5 ="";
                    if (contra1.length()> 8 && contarletras>1 && contarnum > 1){
                        System.out.println("ESTA BUENO");
                        for (int i = 0; i<contra1.length();i++){
                            for(int k =0; k <= contra1.length(); k++)
                                if (k == contra1.length() % 2){
                                    num1+= contra1;
                                            
                                }
                        }
                    }
                    else{
                        System.out.println("Debera ingresar una contrasena mayor de 8 caracteres, una letras y un numero ");
                    }// Me quede sin tiempo pero esta buenas las validaciones, solo me falto poner los numeros entre
                    //las palabras pero no sabia como buenas noches.
            }
            
        }
    }
    
}
